//
// Created by 10109 on 2021/12/23.
//

#ifndef YIQINGMANAGEMENT_HEADER_H
#define YIQINGMANAGEMENT_HEADER_H

#include <stdio.h>      // 执行输入和输出
#include <stdlib.h>     // 各种通用工具函数
#include <string.h>     // 处理字符串
#include <windows.h>    // windows的一些系统功能
#include <limits.h>     // 查看一些变量的范围
#include <ctype.h>      // 处理字符
#include <conio.h>      // 控制台输入输出

// 便于光标定位整齐
#define POS_X0 1
#define POS_X1 45
#define POS_X2 50
#define POS_X3 60
#define POS_X4 75

// 数组大小
#define MAX_NUM 100
#define NAME_LEN 10
#define TITLE_LEN 50
#define CONTENT_LEN 200
#define TIME_LEN 20

// 各个储存文件名称
#define INPUT_FILE_NAME "household_input.txt"
#define HOUSEHOLD_FILE_NAME "houseHold.txt"
#define OUTSIDERS_FILE_NAME "outsiders.txt"
#define NOTICE_FILE_NAME "notice.txt"
#define EMERGENCY_FILE_NAME "emergency.txt"
#define DEFAULT_USERNAME "username"
#define DEFAULT_PASSWORD "password"

// 枚举类型 健康码和健康状态
enum health_code { green, yellow, red};
enum health_status { normal, isolation, ill, death, cured};

struct time {
    int year;
    int mon;
    int day;
    int hour;
    int min;
    int sec;
};
// 住户结构体
struct houseHold_info {
    char name[NAME_LEN];
    char id[18 + 1];
    char tel[11 + 1];
    char house_num[6 + 1]; // 如010304 1栋304户
    char car_num[10 + 1];
    enum health_code health_code;   // green yellow red
    enum health_status health_status;
};
// 外来人员结构体
struct outSider_info {
    char name[NAME_LEN];
    char id[18 + 1];
    char tel[11 + 1];
    char house_num[6 + 1];
    char car_num[10 + 1];
    enum health_code health_code;
    struct time in_time;
    struct time out_time;
};
// 公告结构体
struct notice_info {
    char title[TITLE_LEN];
    char content[CONTENT_LEN];
    struct time date;
};
// 紧急事件结构体
struct emergency_info {
    char event[CONTENT_LEN];
    struct time date;
};

// 管理员登录
int checkIn();
// 打印菜单
int PrintMenu();
// 每个列表的打印
void PrintHouseHold();
void PrintOutSiders();
void PrintNotice();
void PrintEmergency();
// 每个结构体的单个打印
void PrintOneHouseHold();
void PrintOneOutSiders();
void PrintOneNotice();
void PrintOneEmergency();
// 添加各个数据菜单
void AppendHouseHold();
void AppendOutSider();
void AppendNotice();
void AppendEmergency();
// 住户信息查询
void SearchHouseHold();
void SearchName();          // 按姓名查找
void SearchTel();           // 按手机号查找
void SearchID();            // 按身份证号查找
void SearchCarNum();        // 按车牌号查找
void SearchHouseNum();      // 按门牌号查找
// 住户信息健康状态统计
void HealthStatistics();
// 各个数据存储到相应的文件中
void StoreHouseHold(struct houseHold_info info);
void StoreOutSider(struct outSider_info info);
void StoreHouseHoldAll(struct houseHold_info *temp,int num);
void StoreOutSiderAll(struct outSider_info *temp,int num);
void StoreNotice(struct notice_info info);
void StoreEmergency(struct emergency_info info);
// 从相应文件中拿取各个数据
int GetHouseHoldStore(char *file_name);
int GetOutSiderStore(char *file_name);
int GetNoticeStore(char *file_name);
int GetEmergencyStore(char *file_name);
// 工具函数
void SetPosition(int x, int y);     // 设置起始位置
int TxtLine(char *fname);           // txt文件中的换行符数量
struct time getNowTime();           // 获取当前系统时间

#endif //YIQINGMANAGEMENT_HEADER_H
