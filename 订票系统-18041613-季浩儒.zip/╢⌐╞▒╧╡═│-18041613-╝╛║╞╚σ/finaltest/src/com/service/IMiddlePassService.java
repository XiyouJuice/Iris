package com.service;

import java.util.List;

public interface IMiddlePassService {
	List<String[]> changePass(String start_station, String end_station);
}
